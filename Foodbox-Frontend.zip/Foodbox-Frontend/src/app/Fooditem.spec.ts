import { FoodItem } from './Fooditem';

describe('Fooditem', () => {
  it('should create an instance', () => {
    expect(new FoodItem()).toBeTruthy();
  });
});