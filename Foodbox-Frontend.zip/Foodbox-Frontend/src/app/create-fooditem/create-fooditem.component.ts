import { Component, OnInit } from '@angular/core';
import { FoodItem } from '../Fooditem';
import { FoodItemService } from '../Fooditem.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-create-fooditem',
  templateUrl: './create-fooditem.component.html',
  styleUrls: ['./create-fooditem.component.css']
})
export class CreateFooditemComponent implements OnInit {
  [x: string]: any;
  public Fooditem:FoodItem;
  constructor(private Service:FoodItemService,private router:Router) { 
    this.Fooditem=new FoodItem();
  }

  public createFooditem():void{
    this.FoodItemService.createKitchen(this.Fooditem).subscribe(res=>{
      this.Fooditem=new FoodItem();
      this.router.navigate(['/FooditemsList'])
    });
  }

  ngOnInit(): void {
  }

}
