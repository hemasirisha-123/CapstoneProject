import { Component, OnInit } from '@angular/core';
import { FoodItemService } from '../Fooditem.service';
import { FoodItem } from '../Fooditem';

@Component({
  selector: 'app-search-fooditem',
  templateUrl: './search-fooditem.component.html',
  styleUrls: ['./search-fooditem.component.css']
})
export class SearchFooditemComponent implements OnInit {
  [x: string]: any;
  FooditemCost: number;
  data: any;
  FoodItems:FoodItem[];

  constructor(private FoodItemService:FoodItemService) { }

  public getFooditemByCost():void{
    this.FooditemService.getFooditemByCost(this.FooditemCost).subscribe( data => {
      this.data=data;
      console.log(this.data);
    })
  };

  ngOnInit() {
  }

}
