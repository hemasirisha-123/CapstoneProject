import { Component, OnInit } from '@angular/core';
import { FoodItem } from '../Fooditem';
import { FoodItemService } from '../Fooditem.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fooditems-list',
  templateUrl: './fooditems-list.component.html',
  styleUrls: ['./fooditems-list.component.css']
})
export class FooditemsListComponent implements OnInit {
  FooditemsList: FoodItem[];

  constructor(private FoodItemService:FoodItemService,private router:Router) { }
    public selectItem():void{
      this.router.navigate(['/FooditemsList'])
    }
  ngOnInit() {
    this.FoodItemService.getAllKitchens().subscribe(res=>{
      this.FooditemsList=res;
    });
   
  }

}