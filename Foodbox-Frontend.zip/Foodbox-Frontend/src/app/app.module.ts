import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooditemsListComponent } from './Fooditems-list/Fooditems-list.component';
import { CreateFooditemComponent } from './create-Fooditem/create-Fooditem.component';
import { DeleteFooditemComponent } from './delete-Fooditem/delete-Fooditem.component';
import { SearchFooditemComponent } from './search-Fooditem/search-Fooditem.component';
import {FormsModule} from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    FooditemsListComponent,
    CreateFooditemComponent,
    DeleteFooditemComponent,
    SearchFooditemComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
